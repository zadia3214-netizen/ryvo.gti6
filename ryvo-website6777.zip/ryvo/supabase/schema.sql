create table if not exists games (id serial primary key, name text unique not null, sort int default 0);
create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null, title text not null, cat text, game text, gcat text,
  description text, body text, image_url text, sources jsonb default '[]',
  author text default 'RYVO Team', rumor boolean default false, featured boolean default false,
  published boolean default false, published_at date default current_date, updated_at date default current_date);
create table if not exists faqs (
  id uuid primary key default gen_random_uuid(),
  q text not null, cat text, a text, sources jsonb default '[]', rumor boolean default false,
  popularity int default 0, checked date, published boolean default true);
create table if not exists clips (
  id uuid primary key default gen_random_uuid(),
  title text not null, game text, youtube_id text, is_short boolean default false, published boolean default true);
create table if not exists admins (email text primary key);

alter table games enable row level security; alter table posts enable row level security;
alter table faqs enable row level security;  alter table clips enable row level security;
alter table admins enable row level security;

create or replace function is_admin() returns boolean language sql stable security definer as
$$ select exists(select 1 from admins where email = auth.jwt()->>'email') $$;

create policy "read games" on games for select using (true);
create policy "read posts" on posts for select using (published or is_admin());
create policy "read faqs"  on faqs  for select using (published or is_admin());
create policy "read clips" on clips for select using (published or is_admin());
create policy "admin games" on games for all using (is_admin()) with check (is_admin());
create policy "admin posts" on posts for all using (is_admin()) with check (is_admin());
create policy "admin faqs"  on faqs  for all using (is_admin()) with check (is_admin());
create policy "admin clips" on clips for all using (is_admin()) with check (is_admin());

insert into storage.buckets (id,name,public) values ('images','images',true) on conflict do nothing;
create policy "public read images" on storage.objects for select using (bucket_id='images');
create policy "admin write images" on storage.objects for all using (bucket_id='images' and is_admin()) with check (bucket_id='images' and is_admin());
-- After creating your login user, run:  insert into admins values ('you@example.com');

-- Added in v2
alter table faqs add column if not exists slug text unique;
create policy "self admin" on admins for select using (email = auth.jwt()->>'email');

alter table posts add column if not exists section text;
