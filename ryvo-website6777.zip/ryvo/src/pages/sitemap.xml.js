import { posts, games, faqs, slugify, SECTIONS } from '../lib/db.js';
export async function GET({ site }) {
  const base = site.href.replace(/\/$/, ''), today = new Date().toISOString().slice(0, 10);
  const fixed = ['/', '/news', '/gta-vi', '/games', '/guides', '/faq', '/clips', '/about', '/contact'].map(u => [u, today]);
  const urls = [...fixed, ...SECTIONS.map(s => [`/gta-vi/${s.slug}`, today]), ...(await posts()).map(p => [`/news/${p.slug}`, p.updated_at]),
    ...(await games()).map(g => [`/games/${slugify(g.name)}`, today]), ...(await faqs()).map(f => [`/faq/${f.slug}`, f.checked || today])];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(([u, d]) => `  <url><loc>${base}${u}</loc><lastmod>${d}</lastmod></url>`).join('\n')}\n</urlset>`;
  return new Response(xml, { headers: { 'Content-Type': 'application/xml' } });
}
