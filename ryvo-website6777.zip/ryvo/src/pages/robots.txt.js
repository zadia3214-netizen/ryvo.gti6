export const GET = ({ site }) => new Response(`User-agent: *\nAllow: /\nDisallow: /admin/\nSitemap: ${new URL('sitemap.xml', site).href}\n`, { headers: { 'Content-Type': 'text/plain' } });
