import { createClient } from '@supabase/supabase-js';
import fs from 'node:fs';
const db = createClient(process.env.PUBLIC_SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);
const c = JSON.parse(fs.readFileSync(new URL('./content.json', import.meta.url)));
const chk = (label, { error }) => { if (error) { console.error(label, error.message); process.exit(1); } console.log('ok', label); };
const src = a => (a || []).map(([name, url]) => ({ name, url }));
chk('games', await db.from('games').upsert(c.games.map(g => ({ name: g.name, sort: g.s })), { onConflict: 'name' }));
chk('posts', await db.from('posts').upsert(c.posts.map(p => ({
  slug: p.slug, title: p.title, cat: p.cat, section: p.sec, game: p.game, gcat: p.gcat, description: p.desc, body: p.body,
  sources: src(p.src), author: p.author, rumor: !!p.rumor, featured: !!p.feat, published: !!p.pub,
  published_at: p.date, updated_at: p.upd })), { onConflict: 'slug' }));
chk('faqs', await db.from('faqs').upsert(c.faqs.map(f => ({ slug: f.q.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,''), q: f.q, cat: f.cat, a: f.a, rumor: !!f.rumor,
  popularity: f.pop || 0, checked: f.checked, sources: src(f.src) })), { onConflict: 'slug' }));
chk('clips', await db.from('clips').insert(c.clips.map(k => ({ title: k.t, game: k.game, youtube_id: k.yt || null, is_short: !!k.short }))));
