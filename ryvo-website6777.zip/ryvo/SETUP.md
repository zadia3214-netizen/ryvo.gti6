# RYVO setup (no coding needed)
You need 3 free accounts: Supabase (database), GitHub (stores the files), Netlify (hosts the site).

## 1. Supabase (database + login + images)
1. supabase.com > New project (save the database password somewhere).
2. Left menu **SQL Editor** > New query > paste ALL of `supabase/schema.sql` > Run.
3. Left menu **Authentication > Users > Add user**: enter YOUR email + a password. Tick "Auto confirm".
4. SQL Editor again, run:  `insert into admins values ('YOUR-EMAIL-HERE');`
5. **Project Settings > API**: copy the *Project URL* and the *anon public key*.

## 2. GitHub
Create a free account > New repository (Private is fine) > "uploading an existing file" > drag in the
CONTENTS of this folder (unzipped; do not upload node_modules) > Commit.

## 3. Netlify (free hosting)
1. netlify.com > Add new site > Import from GitHub > pick the repository. Build settings are read from netlify.toml.
2. Before deploying, open **Site configuration > Environment variables** and add:
   - `PUBLIC_SUPABASE_URL` = Project URL
   - `PUBLIC_SUPABASE_ANON_KEY` = anon public key
   - `PUBLIC_SITE_URL` = your Netlify address (e.g. https://ryvo.netlify.app), or your own domain later
3. Deploy. Then **Site configuration > Build & deploy > Build hooks > Add build hook**, copy the URL,
   add it as `PUBLIC_DEPLOY_HOOK_URL`, and redeploy once. This powers the "Update live site" button.

## 4. Use it
Go to `YOUR-SITE/admin`, sign in, click **Import starter content**, then **Update live site**.
Edit, delete, save drafts, publish and upload images there. After changes, press **Update live site**
(the public site is rebuilt in 1-3 minutes).

Notes: never share the Supabase *service role* key; this project does not need it.
Do not post your deploy-hook URL publicly (anyone with it can trigger rebuilds).
